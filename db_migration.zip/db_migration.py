import os
import sys
import subprocess
import json

# Define a function to install dependencies at runtime
def install_dependencies():
    package_dir = "/tmp/python"
    
    if not os.path.exists(package_dir):
        os.makedirs(package_dir)

    # Install psycopg2 and sentry-sdk to /tmp/python
    subprocess.check_call([sys.executable, "-m", "pip", "install", "sentry-sdk", "-t", package_dir])
    subprocess.check_call([sys.executable, "-m", "pip", "install", "psycopg2-binary", "-t", package_dir])

    # Add the installed packages to sys.path
    sys.path.insert(0, package_dir)

# Install dependencies at runtime
install_dependencies()

# Now import the dependencies
import sentry_sdk
import psycopg2

# Initialize Sentry
sentry_sdk.init(dsn=os.getenv("SENTRY_DSN"), traces_sample_rate=1.0)

def lambda_handler(event, context):
    try:
        conn = psycopg2.connect(
            host=os.getenv("DB_HOST"),
            database=os.getenv("DB_NAME"),
            user=os.getenv("DB_USER"),
            password=os.getenv("DB_PASSWORD")
        )
        cursor = conn.cursor()

        if event["httpMethod"] == "POST":
            body = json.loads(event["body"])
            task_name = body.get("name", "")
            cursor.execute("INSERT INTO tasks (name) VALUES (%s)", (task_name,))
            conn.commit()
            return {"statusCode": 201, "body": json.dumps({"message": "Task added!"})}
        
        elif event["httpMethod"] == "GET":
            cursor.execute("SELECT name FROM tasks")
            tasks = cursor.fetchall()
            return {"statusCode": 200, "body": json.dumps([{"name": task[0]} for task in tasks])}

    except Exception as e:
        sentry_sdk.capture_exception(e)
        return {"statusCode": 500, "body": f"Error: {str(e)}"}

    finally:
        cursor.close()
        conn.close()
